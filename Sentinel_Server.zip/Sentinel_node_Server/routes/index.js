﻿'use strict';
var express = require('express');
var router = express.Router();
var mssql = require('mssql');

var connectionConfig = {
    user: 'sa',					//사용자
    password: '1234',				//비밀번호
    server: '10.10.14.56',		//서버주소
    port: '1433',					//서버포트
    database: 'Sentinel'
}
/* GET home page. */
router.get('/', function (req, res) {
    res.render('index', { title: 'Sentitel' });
});


//자기아이디 가져오기   매개변수 주민등록번호
router.post('/GetUserId_Select', function (req, res) {
    var residentNum = req.body.ResidentNum;
    console.log(`주민등록번호 : ${residentNum}`);

    const pool = new mssql.ConnectionPool(connectionConfig, err => {

        var request = pool.request();
        request.input('residentNum', mssql.NVarChar, residentNum);
        request.execute(
            'User_SelectWithUserIdByResidentNum',
            (err, result, returnValue) => {

                console.log(`조회된 아이디 ${result.recordset[0].UserID} + ${result.recordset[0].Name}`);
                res.json(result.recordset);

            });
    });
    

});

//비정상 맥박 통계 조회   안드로이드 To 서버에 요청 매개변수 아이디값
router.post('/RiskStatusRecords_Select', function (req, res) {
    var userID = req.body.UserID;
    console.log(`조회 될 유저아이디 : ${userID}`);
    
    const pool = new mssql.ConnectionPool(connectionConfig, err => {

        var request = pool.request();
        request.input('userId', mssql.Int, userID);
        request.execute(
            'RiskStatusRecords_Select',
            (err, result, returnValue) => {
                    console.log(`조회된 데이터 ${result.recordset}`);
                    console.log(`조회된 데이터 ${result.recordset[0].HeartRateStatus} // ${result.recordset[0].RiskLevel} // ${result.recordset[0].RiskStatusTime}`);

                    res.json(result.recordset);

            });
    });
    
});
//정상 맥박 통계조회 (시간별)
router.post('/HeartRateStatistics_Select_By_Hours', function (req, res) {
    var userID = req.body.UserID;
    console.log(`조회 될 유저아이디 : ${userID}`);

    const pool = new mssql.ConnectionPool(connectionConfig, err => {

        var request = pool.request();
        request.input('userId', mssql.Int, userID);
        request.execute(
            'HeartRateStatistics_SelectByHours',
            (err, result, returnValue) => {

                console.log(`조회된 데이터 ${result.recordset}`);

                console.log(`조회된 데이터 ${result.recordset[0].HeartRateAvg} // ${result.recordset[0].Term} `);

                res.json(result.recordset);

            });
    });

});

//정상 맥박 통계조회 (일간별)
router.post('/HeartRateStatistics_Select_By_Daily', function (req, res) {
    var userID = req.body.UserID;
    console.log(`조회 될 유저아이디 : ${userID}`);

    const pool = new mssql.ConnectionPool(connectionConfig, err => {

        var request = pool.request();
        request.input('userId', mssql.Int, userID);
        request.execute(
            'HeartRateStatistics_SelectByDates',
            (err, result, returnValue) => {
                    console.log(`조회된 데이터 ${result.recordset}`);            
                    console.log(`조회된 데이터 ${result.recordset[0].HeartRateAvg} // ${result.recordset[0].Term} `);

                    res.json(result.recordset);

            });
    });

});


//맥박 1분간격 저장  안드로이드 To 서버
router.post('/HeartRateStatus_Insert', function (req, res) {
    var measureTime = req.body.MeasureTime;
    var userID = req.body.UserID;
    var heartRate = req.body.HeartRate;
    console.log(`맥박저장시간: ${measureTime}`);
    console.log(`유저 아이디 : ${userID}`);
    console.log(`맥박 상태 : ${heartRate}`);

    const pool = new mssql.ConnectionPool(connectionConfig, err => {

        var request = pool.request();
        request.input('measureTime', mssql.NVarChar, measureTime);
        request.input('userId', mssql.Int, userID);
        request.input('heartRate', mssql.Int, heartRate);
        request.execute(
            'HeartRateStatus_insert',
            (err, result, returnValue) => {
                
            });
    });

    res.status(200);
});

//맥박 비정상상태 저장   안드로이드 To 서버
router.post('/RiskStatusRecords_Insert', function (req, res) {
    var userID = req.body.UserID;
    var riskStatusTime = req.body.RiskStatusTime;
    var riskLevel = req.body.RiskLevel;
    var heartRateStatus = req.body.HeartRateStatus;
    console.log(`유저아이디 : ${userID}`);
    console.log(`비정상맥박 발생시간 : ${riskStatusTime}`);
    console.log(`맥박 맥박수치 : ${heartRateStatus}`);
    console.log(`맥박 위험수준 : ${riskLevel}`);

    const pool = new mssql.ConnectionPool(connectionConfig, err => {

        var request = pool.request();
        request.input('userId', mssql.Int, userID);
        request.input('riskStatusTime', mssql.NVarChar, riskStatusTime);
        request.input('riskLevel', mssql.NVarChar, riskLevel);
        request.input('heartRateStatus', mssql.Int, heartRateStatus);
        request.execute(
            'RiskStatusRecords_Insert',
            (err, result, returnValue) => {
            
            });
    });
    res.status(200);
});


//QR코드 사용할때 쓸 함수
router.get('/QR_User_Information', (req, res, next) => {
    var userID = req.param('UserID');
 
    const pool = new mssql.ConnectionPool(connectionConfig, err => {


        var request = pool.request();
        request.input('userId', mssql.Int, userID);
        request.execute(
            'User_SelectByInformation',
            (err, result, returnValue) => {

                console.log(`조회된 데이터 
    ${result.recordset[0].Name}
    ${result.recordset[0].ResidentNum} 
    ${result.recordset[0].BloodType}
    ${result.recordset[0].Disease}
    ${result.recordset[0].Hospital}
    ${result.recordset[0].FamilyDoctor}
    ${result.recordset[0].ProtectorPhone}
`);
                res.render('sql', {
                    name: result.recordset[0].Name ,
                    regidentNum: result.recordset[0].ResidentNum,
                    bloodType: result.recordset[0].BloodType,
                    disease: result.recordset[0].Disease,
                    hospital: result.recordset[0].Hospital,
                    familyDoctor: result.recordset[0].FamilyDoctor,
                    protectorPhone: result.recordset[0].ProtectorPhone
                });
               
            });
    });
    
});


module.exports = router;

